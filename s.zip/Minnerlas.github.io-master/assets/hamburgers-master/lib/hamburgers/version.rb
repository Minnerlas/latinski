module Hamburgers
  VERSION = "1.1.3"
end
